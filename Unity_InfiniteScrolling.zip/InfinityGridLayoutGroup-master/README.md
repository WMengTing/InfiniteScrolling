# InfinityGridLayoutGroup
InfinityGridLayoutGroup there are many in need scrolling substitute GridLayoutGroup

无限滚动GridLayoutGroup,动态创建滚动Item;


实现无限滚动，需要的最少的child数量。屏幕上能看到的+一行看不到的，比如我在屏幕上能看到 2 行，每一行 2 个。则这个值为 2行*2个 + 1 行* 2个 = 6个。

﻿using UnityEngine;using System.Collections;using UnityEngine.UI;using System;using System.Collections.Generic;namespace ThisisGame{    public class TestEmailUI2 : MonoBehaviour    {



        #region RankInfo        private InputField userNameInput;   // 用户名输入框
        private InputField userScoreInput;  // 用户成绩输入框
        private Button saveButton;          // 保存按钮
        private Button deleteButton;        // 删除按钮
        private Button clearButton;         // 清空按钮

        #endregion
        

List<Dictionary<string, object>> rankList;        InfinityGridLayoutGroup infinityGridLayoutGroup;        int amount;

        // Use this for initialization
        void Start()        {


            #region 数据库处理            SQLiteManager.Instance.LoadDatabase("TestRankDB");            SQLiteManager.Instance.ExecuteNonQuery("create table if not exists RankList(UserName text primary key, UserScore integer, UserTime text)");


            #endregion
            rankList = ReloadData();            amount = rankList.Count;


            //deleteButton = transform.root.Find("RankPanel/OperationPanel/DeleteButton").GetComponent<Button>();
            //deleteButton.onClick.AddListener(RefreshData);

            #region 获取UI控件            userNameInput = transform.root.Find("Panel/OperationPanel/UserNameInput").GetComponent<InputField>();            userScoreInput = transform.root.Find("Panel/OperationPanel/UserScoreInput").GetComponent<InputField>();            saveButton = transform.root.Find("Panel/OperationPanel/SaveButton").GetComponent<Button>();            clearButton = transform.root.Find("Panel/OperationPanel/ClearButton").GetComponent<Button>();




            #endregion
            #region 存储信息            saveButton.onClick.AddListener(SaveAction);


            #endregion
            ////初始化数据列表;
            infinityGridLayoutGroup = transform.Find("Panel/RankPanel/BackGround/Panel_Scroll/Panel_Grid").GetComponent<InfinityGridLayoutGroup>();            infinityGridLayoutGroup.SetAmount(amount);            infinityGridLayoutGroup.updateChildrenCallback = UpdateChildrenCallback;        }        void RefreshData()
        {            rankList = ReloadData();            amount = rankList.Count;        }

        //  void OnGUI()
        //  {
        //      if (GUILayout.Button("Add one item"))
        //      {
        //          infinityGridLayoutGroup.SetAmount(++amount);               
        //      }
        //      if (GUILayout.Button("remove one item"))
        //      {
        //          infinityGridLayoutGroup.SetAmount(--amount);
        //      }
        //  }

        void UpdateChildrenCallback(int index, Transform trans)        {            Debug.Log("UpdateChildrenCallback: index=" + index + " name:" + trans.name);            Text text = trans.Find("Text").GetComponent<Text>();            text.text = index.ToString();            Dictionary<string, object> result = rankList[index % rankList.Count];

            trans.Find("Name").GetComponent<Text>().text = result["UserName"] as string;            trans.Find("Score").GetComponent<Text>().text = result["UserScore"].ToString();            trans.Find("Time").GetComponent<Text>().text = result["UserTime"] as string;        }







        /// <summary>        /// 存储信息        /// </summary>        private void SaveAction()
        {            string userName = userNameInput.text ?? "";            string userScore = userScoreInput.text ?? "";            string userTime = DateTime.Now.ToString("HH:mm");
            //将以上信息保存到数据库
            string sql = "insert into RankList values('" + userName + "', " + userScore + ", '" + userTime + "')";            SQLiteManager.Instance.ExecuteNonQuery(sql);
            //infinityGridLayoutGroup.updateChildrenCallback = UpdateChildrenCallback;
        }






        /// <summary>        /// 刷新界面        /// </summary>        private List<Dictionary<string, object>> ReloadData()
        {
            //移除所有子物体
            List<Dictionary<string, object>> result = SQLiteManager.Instance.ExecuteQuery("select * from RankList order by UserScore desc");            Debug.Log("查询结果" + result.Count);            return result;        }        private void OnDestroy()        {            SQLiteManager.Instance.Close();        }    }}
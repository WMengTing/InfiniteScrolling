﻿using System.Collections.Generic;
using UnityEngine;
using Mono.Data.Sqlite;

public class SQLiteManager {
    public static readonly SQLiteManager Instance = new SQLiteManager();
    private SQLiteManager() { }

    private SqliteConnection connection;
    private SqliteCommand command;
    private SqliteDataReader reader;

    /// <summary>
    /// 通过一个数据库的名称来加载一个数据库
    /// </summary>
    /// <param name="sqliteName">数据库的名称</param>
    public void LoadDatabase(string sqliteName) {
        // 1、容错判断
        if (!sqliteName.EndsWith(".sqlite")) {
            sqliteName += ".sqlite";
        }
        // 2、拼接数据库的路径
        string sqlitePath = "Data Source = " + Application.streamingAssetsPath + "/" + sqliteName;
        Debug.Log(sqlitePath);
        // 3、建立与数据库的连接
        connection = new SqliteConnection(sqlitePath);
        // 4、获取操作操作指令对象
        command = connection.CreateCommand();
        // 5、打开数据库
        Open();
    }

    /// <summary>
    /// 打开数据库
    /// </summary>
    public void Open() {
        try {
            connection.Open();
        } catch (SqliteException e) {
            Debug.LogWarning("数据库打开异常! " + e.ToString());
        }
    }

    /// <summary>
    /// 关闭数据库
    /// </summary>
    public void Close() {

        try {
            // 先判断reader是否是关闭的, 如果没有关闭, 先关闭reader
            if (reader != null && reader.IsClosed == false) {
                reader.Close();
            }

            connection.Close();
        } catch (SqliteException e) {
            Debug.LogWarning("数据库关闭异常! " + e.ToString());
        }

    }
    
    /// <summary>
    /// 执行非查询操作
    /// </summary>
    /// <param name="sql">要执行的SQL语句</param>
    public void ExecuteNonQuery(string sql) {

        command.CommandText = sql;
        try {
            command.ExecuteNonQuery();
        } catch (SqliteException e) {
            Debug.LogWarning("操作异常! " + e.ToString());
        }
    }

    /// <summary>
    /// 执行查询操作
    /// </summary>
    /// <param name="sql">要执行的SQL语句</param>
    /// <returns>查询的结果</returns>
    public List<Dictionary<string, object>> ExecuteQuery(string sql) {

        // 实例化一个集合, 用来存储最终的结果
        List<Dictionary<string, object>> result = new List<Dictionary<string, object>>();

        // 执行查询操作
        command.CommandText = sql;
        try {
            reader = command.ExecuteReader();

            // 循环读取查询到的每一行的内容
            while (reader.Read()) {
                // 实例化一个Dictionary<string, object>，用来存储查询到每一行的键值对
                Dictionary<string, object> item = new Dictionary<string, object>();
                // 遍历查询到的一行的内容中所有的键
                for (int i = 0; i < reader.FieldCount; i++) {
                    // 将查询到的键和值存储到item中
                    item[reader.GetName(i)] = reader.GetValue(i);
                }
                // 在将这个存储了所有键值信息的Dictionary存储到result中
                result.Add(item);
            }
            
            reader.Close();

        } catch (SqliteException e) {
            Debug.LogWarning("查询异常！" + e.ToString());
        }
        
        return result;
    }	
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UIRankTip : MonoBehaviour {

    public static UIRankTip instance;
    private bool isShow = false;
    private Button btn;
    private Animator ani;

    private void Start()
    {
        transform.GetComponent<Animator>();
        btn =GameObject.Find("Rank_Btn").GetComponent<Button>();
        ani= transform.GetComponent<Animator>();
        btn.onClick.AddListener(Controller);          
    }
    private void Controller()
    {
        ani.SetBool("Open", !ani.GetBool("Open"));
    }

}

﻿using UnityEngine;using System.Collections;using UnityEngine.UI;namespace ThisisGame{    public class TestEmailUI : MonoBehaviour    {        InfinityGridLayoutGroup infinityGridLayoutGroup;        int amount = 20;//Content下最多能容纳的格子数量

        void Start()        {
            ////初始化数据列表;
            infinityGridLayoutGroup = transform.Find("Panel_Scroll/Panel_Grid").GetComponent<InfinityGridLayoutGroup>();            infinityGridLayoutGroup.SetAmount(amount);            infinityGridLayoutGroup.updateChildrenCallback = UpdateChildrenCallback;//刷新格子回调        }        /// <summary>
        /// 刷新格子
        /// </summary>
        /// <param name="index">格子index</param>
        /// <param name="trans">显示格子index的标记</param>        void UpdateChildrenCallback(int index, Transform trans)        {            Debug.Log("UpdateChildrenCallback: index=" + index + " name:" + trans.name);            Text text = trans.Find("Text").GetComponent<Text>();            text.text = index.ToString();        }    }}
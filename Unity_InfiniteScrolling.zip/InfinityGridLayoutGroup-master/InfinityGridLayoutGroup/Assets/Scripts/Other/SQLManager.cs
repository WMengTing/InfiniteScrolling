﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mono.Data.Sqlite;

public class SQLManager  { 

    private SqliteConnection connection;
    private SqliteCommand command;
    private SqliteDataReader reader;


    //单例
    public static readonly SQLManager Instance = new SQLManager();
    protected SQLManager() { }


    /// <summary>
    ///加载一个数据库 
    /// </summary>
    /// <param name="sqliteName"></param>
    public void LoadDataBase(string sqliteName)
    {
        //名称容错
        if (!sqliteName.EndsWith(".sqlite")) sqliteName += "sqlite";
        //拼接数据库路径
        string sqlitePath = "Data Source=" + Application.streamingAssetsPath + "/" + sqliteName;
        //连接数据库
        connection = new SqliteConnection(sqlitePath);
        //创建SQLiteCommand对象
        command = connection.CreateCommand();
        //打开数据库
        Open();
    }

    /// <summary>
    /// 执行非查询语句
    /// </summary>
    /// <param name="sql"></param>
    public void ExecuteNonQuery(string sql)
    {
        command.CommandText = sql;
        try
        {
            command.ExecuteNonQuery();
        }catch(SqliteException e)
        {
            Debug.LogWarning("操作异常" + e.ToString());
        }
    }

    /// <summary>
    /// 单项查询
    /// </summary>
    /// <param name="sql"></param>
    /// <returns></returns>
    public object ExecuteScale(string sql)
    {
        command.CommandText = sql;
        try
        {
            return command.ExecuteScalar();
        }catch (SqliteException e)
        {
            Debug.LogWarning("查询异常" + e.ToString());
            return null;
        }
    }

    /// <summary>
    /// 执行多项查询
    /// </summary>
    /// <param name="sql"></param>
    /// <returns></returns>
    public List<Dictionary <string ,object >>ExecuteReader(string sql)
    {
        command.CommandText = sql;

        List<Dictionary<string, object>> result = new List<Dictionary<string, object>>();

        try {

            reader = command.ExecuteReader();

            while (reader.Read()) {
                Dictionary<string, object> item = new Dictionary<string, object>();

                for (int i = 0; i < reader.FieldCount; i++) {
                    item[reader.GetName(i)] = reader.GetValue(i);
                }

                result.Add(item);
            }
            
            reader.Close();
            
        } catch (SqliteException e) {
            Debug.LogWarning("查询异常: " + e.ToString());
        }

        return result;
    }
    
    /// <summary>
    /// 打开数据库
    /// </summary>
    public void Open()
    {
        try
        {
            connection.Open();
        }catch (SqliteException e)
        {
            Debug.LogWarning("数据库打开失败" + e.ToString());
        }

    }


    public void Close()
    {
        try
        {
            if (reader.IsClosed == false) reader.Close();
            connection.Close();
        }catch (SqliteException e)
        {
            Debug.LogWarning("数据库关闭失败" + e.ToString());
        }

    }

}

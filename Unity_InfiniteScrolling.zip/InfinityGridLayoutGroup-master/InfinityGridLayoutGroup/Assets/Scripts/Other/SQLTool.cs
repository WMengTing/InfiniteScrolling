﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 用来储存每个关卡的信息
/// </summary>
public struct LevelInfo
{
    public int LevelID;
    public int LevelStar;
}


public class SQLTool : SQLManager  {

    //做成单例
    public static readonly new SQLTool Instance = new SQLTool();
    private SQLTool()
    {
        //创建数据库
        LoadDataBase("Levels");
        //建表
        ExecuteNonQuery("create table if not exists LevelInfo(LevelID integer primary key,LevelStar integer)");


        //往数据库中添加数据
        InsertData(1, 0);
        for(int i = 2; i <= 10; i++)
        {
            InsertData(1, -1);
        }
    }
    /// <summary>
    /// 增数据
    /// </summary>
    /// <param name="id"></param>
    /// <param name="star"></param>
    public void InsertData(int id,int star)
    {
        ExecuteNonQuery("insert into LevelInfo values("+id+","+star+")");
    }

    /// <summary>
    /// 改数据
    /// </summary>
    /// <param name="id"></param>
    /// <param name="star"></param>
    public void UpdateData(int id,int star)
    {
        ExecuteNonQuery("update LevelInfo set LevelStar="+star+"where LevelID="+id);
    }

    /// <summary>
    /// 通过关卡号，查询这个关卡对应的星级
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public int GetStar(int id)
    {
        object result = ExecuteScale("select LevelStar from LevelInfo where LevelID="+id);

        if (result == null) return 0;
        return (int)(long)result;
    }


    public List<LevelInfo> QueryAll()
    {
        List<Dictionary<string, object>> result = ExecuteReader("select*from LevelInfo");
        //用来储存所有的结果
        List<LevelInfo> resultList = new List<LevelInfo>();

        foreach (Dictionary <string ,object >item in result)
        {
            //实例化一个结构体对象
            LevelInfo info = new LevelInfo();
            info.LevelID = (int)(long)item["LevelID"];
            info.LevelStar = (int)(long)item["LevelStar"];

            resultList.Add(info);
        }
        return resultList;
    }
}

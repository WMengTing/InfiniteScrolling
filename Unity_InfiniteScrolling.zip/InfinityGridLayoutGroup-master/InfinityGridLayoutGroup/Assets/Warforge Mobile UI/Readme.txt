Warforge Mobile UI for UGUI (v1.0)
August 15, 2015

Artist: EvilSystem (evilsystem.eu / evil-s.deviantart.com )
Developer: ChoMPi (chompibg@gmail.com)
Contact: evilsystem@duloclan.com 

This is a mobile-friendly UI for Unity GUI. 

* Requires Unity 5.2!

The product features:

- PSD Files 
- Vector Design (Scalable) 
- Sliced images (PNG, High Resolution) 
- 40 button icons 
- Fonts included 
- Custom scripts 
- Demo scenes 
- Prefabs 

The demo scenes are setup to scale with the screen size relative to 1920x1080.
The images are sliced from PSD files scaled up to 200%.

Contact me if you need any assistance or have a question. 
With best regards, Evil.